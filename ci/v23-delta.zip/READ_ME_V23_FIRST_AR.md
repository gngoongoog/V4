# تشغيل BRAINTRADE Enterprise V23

هذه **حزمة مصدر** وليست برنامج Windows جديداً. احتفظ بنسخة Portable V19 السابقة بشكل منفصل؛ لا تستبدل ملف EXE القديم بملفات Rust المصدرية.

## طريقة بناء النسخة المحمولة على Windows

1. فك ضغط هذا الملف كاملاً داخل مسار قصير، مثلاً `C:\BRAINTRADE-V23`.
2. ثبّت Visual Studio 2022 C++ Build Tools وRust stable MSVC x64 وNode.js 22 وPython 3.13 x64. استخدم نسخة MT5 المثبّتة لديك للاختبارات اللاحقة.
3. افتح `BUILD_V23_PORTABLE.cmd`. هذه الخطوة تقوم ببناء جديد لمحرك Rust/تطبيق Tauri، وتختبر الملفات والواجهة، وتُنشئ بيئة Python المحمولة، وترفض تجميع إصدار عند وجود خلل.
4. بعد نجاح جميع المراحل، تجد الحزمة في `target\portable\BRAINTRADE-V4-V23-PORTABLE-Win64.zip`.
5. فك الضغط كاملاً؛ شغّل `START_BRAINTRADE.cmd` على Demo فقط أولاً.
6. لا تستخدم REAL قبل إنهاء اختبارات Windows/MT5 الواردة في `V23_DEVELOPMENT_REPORT_AR.md`.

**ملحوظة:** محرك Rust V23 لم يُجمّع في بيئة هذه المحادثة. الخطوات أعلاه وصف لسكريبت البناء وليست شهادة نجاحه.

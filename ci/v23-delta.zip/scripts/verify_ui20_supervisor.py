"""Non-executable static V20 wiring check, not a Rust build or live demo claim."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
files=["crates/runtime/src/enterprise_supervisor.rs","crates/runtime/src/execution.rs","crates/runtime/src/lib.rs","apps/tauri/src/bridge.rs","apps/terminal/src/enterprise-supervisor.tsx","apps/terminal/src/bridge.ts"]
for name in files:
    p=root/name
    assert p.is_file() and p.stat().st_size>500,(name,"missing/empty")
core=(root/"crates/runtime/src/lib.rs").read_text(encoding="utf-8")
exe=(root/"crates/runtime/src/execution.rs").read_text(encoding="utf-8")
api=(root/"apps/tauri/src/bridge.rs").read_text(encoding="utf-8")
checks={
    "supervisor read/write API":"/v1/enterprise/supervisor" in core,
    "persist before acknowledged save":"enterprise_supervisor::save(&self.db" in core,
    "regular broker entry veto":"let entries_allowed=if run {" in exe and "self.supervisor.enforce_entry_gate" in exe,
    "Sniper fast pulse entry veto":"let enter=if status.requested_run {" in exe and "self.supervisor.enforce_entry_gate" in exe,
    "position management preserved":"self.inner\n            .observe(db, telemetry, config, entries_allowed, frames, now)?" in exe,
    "Tauri path allowlist":"/v1/enterprise/supervisor" in api and "fn update_supervisor" in api,
    "Rust dedicated unit tests":"fn stale_price_never_becomes_new_with_fresh_heartbeat" in (root/files[0]).read_text(),
}
for label,good in checks.items():
    print(("PASS" if good else "FAIL"),label)
assert all(checks.values())
print("V20 wiring checks passed; Rust unit tests and Windows executable are NOT certified.")

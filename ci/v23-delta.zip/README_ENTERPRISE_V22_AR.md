# BRAINTRADE V4 — Enterprise V22 | مصدر تطويري غير مُعتمد للـREAL

الهدف: إغلاق خلل تشخيصي في سياسة المنسّق، منع بقاء مؤشرات ثقة قديمة بعد فقد Core، وإضافة فحص تشغيل Portable داخل بوابة البناء.

## الجديد

1. `crates/runtime/src/enterprise_supervisor.rs`: عند فساد إعدادات SQLite، يعرض Core `configuration_integrity=invalid_fail_closed` ويعلن `entry_gate_enforced=true` و`entry_gate_permits_new_entries=false` بدلاً من تعطل صفحة التشخيص. يبقى تدبير المراكز القائمة منفصلاً عن منع الدخول الجديد. ولا يمكن تعديل هذه السياسة مع انقطاع MT5 أو بيانات مراكز غير موثوقة؛ يجب التحقق من هوية الحساب وحداثة البيانات وخلوه من المراكز والأوامر.
2. `broker_execution_authorization=not_evaluated_by_this_read_only_endpoint` لمنع تفسير فحص بيانات السوق على أنه موافقة نهائية لإرسال أمر وساطة.
3. `apps/terminal/src/enterprise-supervisor.tsx`: انقطاع Core يبطل حالة الثقة ويفصل اللون الإيجابي، ويعيد مزامنة سياسة الحماية المحفوظة عند إعادة الاتصال بدلاً من الإبقاء على معلومات قديمة.
4. `scripts/smoke_portable_core.py`: تجربة Core معزولة **بدون Gateway أو تداول**، تتحقق من التشغيل الآمن بحالة STOPPED، وقراءة حالة مصادق عليها، ثم إغلاق آمن.
5. `BUILD_V22_PORTABLE.cmd` و`scripts/Build-V22-Portable-Windows.ps1`: بوابة تجميع Rust/Tauri والاختبارات وفحص ملفات Gateway وPython؛ لن تطبع ZIP إذا فشل فحص التشغيل المعزول.
6. `DEMO_ACCEPTANCE_V22_AR.md`: معايير اختبار الأوضاع الأربعة والتنفيذ والعمولة وتعلم العقول على Windows/MT5 Demo.

## الفحوص المتاحة في بيئة الإنشاء الحالية

- Python: **268 اختباراً**: 266 ناجحاً و2 متجاوزان، مع ملفات Python المؤقتة معطلة.
- React/Node: 6 مجموعات اجتازت اختبارات الواجهة والعقود المحلية.
- `python scripts/verify_ui22_integrity.py`: 8 فحوص مصدر ناجحة.
- `python scripts/verify_ui18_source.py`: سلامة المصدر ناجحة، مع تحذيرين لم يتم إزالتهما: `package-lock.json` مفقود، و`Cargo.lock` لا يتضمن إصدار Tauri 2 النهائي.
- **Rust V22 لم يُجمّع بعد**؛ Rust regression tests الجديدة لم يتم تشغيلها هنا. Windows/MT5 Demo E2E غير مختبر.

## بناء جديد على Windows

فك ضغط المشروع، ثبّت Node.js وPython 3.13 وRust stable/MSVC وVisual Studio C++ Build Tools، ثم شغّل `BUILD_V22_PORTABLE.cmd`. لا تنقل أي EXE قديم من V18/V19/V20/V21 داخل المصدر وتقول إنه V22. يبدأ اختبار Core المعزول فقط بعد بناء البرنامج وتجهيز ملفات runtime.

## حدود التصميم الحالية

- المنسق الحالي استشاري وليس مبدلاً تلقائياً بين القناص/السكالبر/السوينك/الخبير.
- تتطلب الاستراتيجيات قياسات صافية خارج عينة التدريب ومقارنة شاملة مع نتائج Demo حتى تعتمد.
- Fast Pulse يقلل عمل الاستطلاع لكنه لا يضمن زمن تنفيذ MT5؛ زمن الرد يعتمد الوسيط والجهاز والإنترنت.
- ميزة الأحداث الاقتصادية تعتمد جدولاً تشغيلياً ولا تستورد تقويماً اقتصادياً فورياً موثقاً تلقائياً.
- لم تُختبر كل أزرار التطبيق على Windows Desktop في هذا الإصدار.

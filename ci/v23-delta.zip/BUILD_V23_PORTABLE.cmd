@echo off
setlocal
cd /d "%~dp0"
echo BRAINTRADE V4 V23 - verified native Windows portable release
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Build-V23-Portable-Windows.ps1"
if errorlevel 1 (
 echo V23 BUILD/TEST FAILED - do NOT use an older EXE as V23
 pause
 exit /b 1
)
echo Check target\portable\BRAINTRADE-V4-V23-PORTABLE-Win64.zip
pause

@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo BRAINTRADE V4 V21 - NATIVE WINDOWS PORTABLE BUILD
 echo ============================================================
echo This builds NEW Rust and Tauri binaries, not UI18/V19 copies.
echo Windows x64 / Rust MSVC / Node.js / Python are required.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Build-V21-Portable-Windows.ps1"
if errorlevel 1 (
  echo.
  echo BUILD FAILED: read the compiler output. Do not use an old EXE as V21.
  pause
  exit /b 1
)
echo.
echo SUCCESS. Inspect target\portable for the V21 ZIP.
pause

# BRAINTRADE V4 NEXT — Tauri UI-16 / System Health

**التغيير:** إزالة صورة الوجه الآلي من واجهة البرنامج وموارد الإنتاج، واستبدالها في الشريط الجانبي بلوحة **System Health** متفاعلة. صورة التصميم الأصلية محفوظة للمقارنة داخل `design/` فقط، خارج `public/`، ولا تُضمّن في واجهة Tauri.

## إشارات المراقبة الفعلية

- **Rust Core:** ONLINE عندما يصل رد حديث من قناة Tauri وتبقى رسائل الحالة حديثة بحد أقصى 5 ثوانٍ، وإلا OFFLINE.
- **MT5 Bridge:** CONNECTED فقط إذا أكّد Core حداثة الاتصال `gateway_fresh` واتصال حساب MT5.
- **Market Feed:** FRESH فقط عند توفر `tick_age_ms` حديث لا يتجاوز 3000ms، وإلا UNAVAILABLE.
- **Execution:** ARMED فقط عندما يكون التشغيل مطلوباً فعلياً والمحرك يجيز التنفيذ مع سعر متاح، وSTOPPED عند عدم طلب التشغيل وBLOCKED إن طلب التشغيل دون السماح به.
- **Risk Config:** LOADED فقط عندما تتوفر إعدادات المخاطر ولقطة مراقبتها من Core؛ حالة LOADED **لا تعني** تفعيل جميع قواطع الأمان أو ضمان سلامة التداول.
- **Last Sync:** يبيّن وقت آخر رد Core مؤكد؛ ليس زمن إرسال MT5 ولا استجابة الوسيط. لا توجد نسبة صحة أو CPU أو زمن تنفيذ مختلق.

كل سطر يفتح صفحته (Events, Settings, Analysis, Execution, Risk)، وعنوان System Health يفتح الأحداث. لوحة المعاينة مميزة `DESIGN PREVIEW` وهي **غير قابلة للتداول** ولا تعرض ادعاءات بأن MT5 متصل فعلياً.

## ملفات التغيير

- `apps/terminal/src/system-health.tsx`: دالة اشتقاق الإشارات من Core والمكوّن التفاعلي الجديد.
- `apps/terminal/src/terminal.tsx`: ربط حالة Core وتحديث `lastStatusAt` وعرض المكوّن مكان الوجه الآلي.
- `apps/terminal/src/ui15.css`: تنسيقات الإضاءة والحالات وتجاوب الشريط الجانبي حتى ارتفاع 768px.
- `apps/terminal/tests/health.cjs`: سيناريوهات الحالة واختبارات توجيه أزرار الحالة.
- `apps/terminal/tests/render-health-preview.cjs`: رندر مرئي من JSX الحقيقي للمكوّن، مع خلفية لوحة UI-15 **ثابتة** للتوضيح فقط؛ ليس اختبار Tauri native.
- `visual-proof/UI16_SystemHealth_preview_1648x928.png`: صورة معاينة توضح مكان المكوّن الجديد. يجب عدم اعتبار بقية اللوحة في الصورة رندراً جديداً أو بيانات MT5.

## البناء على ويندوز

مثل UI-15: `powershell -ExecutionPolicy Bypass -File scripts/Build-Tauri-Windows.ps1` من جذر المصدر مع Node.js/Rust MSVC/Build Tools و WebView2 Runtime واتصال الإنترنت لتنزيل التبعيات. لا يحتاج تغيير محرك V4 الأصلي.

**حالة التحقق:** `node tests/contracts.cjs` نجح؛ `node tests/health.cjs` نجح؛ اجتاز مكوّن System Health رندر Chromium بحجم 1648×928 و1366×768 و1024×768 مع عدم وجود صورة آلية. لا تتوفر هذه البيئة على Rust/Cargo أو حزم npm اللازمة لبناء Tauri التنفيذي؛ لم يتم بناء Windows EXE أو إجراء اختبار MT5 Demo حقيقي.

**حدود الإصدار:** الصفحات الـ22 جزء من مشروع UI-15 الأساسي؛ لا يعني استبدال الصورة أن الوظائف الـ22 قد اكتملت وظيفياً أو أن التطبيق جاهز لتداول LIVE.

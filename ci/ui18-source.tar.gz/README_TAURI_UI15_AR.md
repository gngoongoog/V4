# BRAINTRADE V4 NEXT — UI-15 / Tauri 2

هذه أول مرحلة فعلية لإعادة بناء واجهة BRAINTRADE باستخدام Tauri 2 وReact/TypeScript.
**حالة الإصدار: SOURCE PREVIEW — لم يُبنَ المثبّت التنفيذي بعد.**

## ما تم تنفيذه

- مشروع Windows Tauri v2 جديد موجود في `apps/tauri`، موصول مباشرة بحزمة Rust `braintrade-runtime` القائمة.
- React/TypeScript واجهة مستقلة في `apps/terminal`؛ مدخل 22 صفحة، تصميم دخاني/داكن/فاتح، لوحة أقرب إلى صورة 22 أكتوبر.
- شارت Canvas ببيانات شموع MT5 المكتملة (M1/M5/M15)، الحجم، متوسط 11 و25، crosshair، zoom، ومنع افتراض وجود بيانات لفريمات أخرى.
- نقل حالة Core للواجهة عبر Tauri IPC Channel، مع فحص متكرر يقارب 250ms عند الاتصال، 900ms عند الانقطاع. **ليس ضماناً لوصول أسعار MT5 خلال 250ms**.
- البيانات التجريبية مقيدة بوضع المعاينة، لا تُرسل إلى Core. عند انقطاع MT5 لا تظهر أرقام تجريبية باعتبارها حقيقية.
- أوامر البدء/الإيقاف/إعادة الاتصال وتغيير المخاطر/الإعدادات/تحويل القناص تمر بأوامر Tauri مقيدة وتعتمد على التحقق في Rust Core.
- `ipc.key` ورموز الوصول لا تُرسل إلى JavaScript. صفحات JSON المقيدة تستخدم قائمة GET محددة.
- 22 صفحة للانتقال؛ بعض الصفحات الأولية تعرض مباشرة بيانات استرجاع Core في جداول عامة **وليس بعد كافة الشاشات والإجراءات التفصيلية** من واجهة Slint السابقة.
- محرك التداول الأصلي، قواعد التأكد من الحساب، طبقات المخاطر والتعلم، التلغرام، والـMT5 محفوظة بدون تغيير.

## مسارات الملفات

- `apps/terminal/src/terminal.tsx`: واجهة React ولوحة التحكم وصفحات V4.
- `apps/terminal/src/chart.tsx`: شارت الشموع الحقيقي.
- `apps/terminal/src/bridge.ts`: أوامر Tauri/TypeScript.
- `apps/terminal/src/mock.ts`: بيانات المعاينة فقط.
- `apps/tauri/src/bridge.rs`: جسر Rust المحلي والتحقق من الصلاحيات.
- `apps/tauri/src/main.rs`: برنامج Windows الذي يشغل Tauri أو Core الأصلي عند `--core`.
- `scripts/prepare-tauri-runtime.py`: تنزيل Python ومكتبة MT5 المثبتتين بإصدارات وبصمات SHA256.
- `scripts/Build-Tauri-Windows.ps1`: تجهيز واختبار وبناء NSIS Installer على Windows.
- `.github/workflows/tauri-windows.yml`: وظيفة بناء Windows عند رفع الملفات إلى GitHub.
- `visual-proof/UI15_React_*.png`: **صور رندر Chromium لمكونات React بوضع معاينة البيانات، وليست لقطات Windows EXE**. في الاختبار المحلي استخدمنا React 16 موقّتاً لتصيير DOM ونسخاً مبسطة من أيقونات Lucide نتيجة عدم توفر npm؛ البناء الفعلي يتطلب React 18 كما في package.json.

## خطوات البناء على Windows 10/11 x64

1. ثبّت Node.js LTS، Rust MSVC stable، Visual Studio C++ Build Tools (Desktop development with C++) وWebView2 Runtime.
2. فك الملف داخل مجلد لا يحتوي مسافات غريبة ثم افتح PowerShell من جذر المشروع.
3. شغّل: `powershell -ExecutionPolicy Bypass -File scripts/Build-Tauri-Windows.ps1`.
4. السكربت يثبت تبعيات واجهة React وTauri CLI، ينفذ اختبارات الوحدة والبناء، ويحضر Python/MT5 المضمنين ويتحقق من SHA256، وينشئ Installer عبر Tauri.
5. عند نجاح البناء فقط ستجد المثبّت في `target/release/bundle/nsis/`.
6. يجب تجربة التطبيق على Windows حقيقي مع حساب MT5 Demo وتشغيل واجهة العقول، اختبار تغذية الشارت، وإغلاق جميع صفحات التنفيذ في Demo والتأكد من سجلات النظام قبل أي تداول حقيقي.

**ملاحظة:** عملية البناء تحتاج إنترنت لتنزيل تبعيات npm/Rust وملفات Python الموثقة. تعذر تنفيذ Rust/Tauri build في بيئة المساعد الحالية لعدم وجود cargo/rustc وإتاحة تنزيل الحزم. اختبار MATLAB غير مطلوب. لا توجد أدلة على تشغيل `BrainTradeNext.exe` الجديد حتى يتم بناء المثبّت واختباره على Windows.

## اختبارات أجريناها محلياً

- Node contracts لعدد الصفحات 22 وفصل بيانات المعاينة وقيود IPC وقناة 250ms: PASS.
- TypeScript parse/transpile لكل مصادر TS/TSX: PASS.
- TypeScript semantic smoke بواجهات Typing محلية مؤقتة: PASS. **ليس بديلاً عن `npm run build` باستخدام React/Types الرسمية.**
- رندر بصري في Chromium للوحات dashboard, brains, risk, trading: PASS في وضع static fixture؛ لم تجرَ اختبارات نقر حقيقية مع المحرك أو Windows.

## ما يزال قيد التطوير

- الاستجابة النهائية لكل الصفحات الـ22 (الكثير منها حالياً شاشة بيانات مباشرة وليست ميزات إدارة كاملة).
- بناء نسخة Tauri 2 Windows المثبتة فعلياً، وربط MT5 Demo واختبارات انقطاع/عودة الاتصال وتأكيد لقطات Windows الأصلية.
- إدخال تفاصيل التقرير Win Rate/Drawdown/Latency فقط من سجلات موثقة وكافية؛ الأعمدة غير المتاحة تبقى `—`.
- مقارنة Pixel-Perfect مع الصورة المرجعية وتفاصيل أيقونات الحركة والرسومات قبل اعتمادها نهائياً.

هذا مسار تطوير مستقل؛ لا تستبدل نسختك التشغيلية بـ UI-15 إلا بعد نجاح البناء والاختبارات الواقعية.

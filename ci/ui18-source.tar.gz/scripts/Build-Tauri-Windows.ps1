param([switch]$SkipCoreTests,[switch]$SkipPackage)
$ErrorActionPreference='Stop'
$Root=Resolve-Path (Join-Path $PSScriptRoot '..')
Set-Location $Root
$env:PYTHONDONTWRITEBYTECODE = '1'
function Run([string]$Exe,[string[]]$ArgsList) {
  & $Exe @ArgsList
  if ($LASTEXITCODE -ne 0) { throw "$Exe failed: $LASTEXITCODE" }
}
if (-not (Get-Command rustc -ErrorAction SilentlyContinue)) { throw 'Install Rust stable MSVC and Visual Studio C++ Build Tools' }
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Install Node.js LTS' }
if (-not (Get-Command cargo-tauri -ErrorAction SilentlyContinue)) {
  Write-Host 'Installing Tauri v2 build CLI...'
  Run cargo @('install','tauri-cli','--version','^2','--locked')
}
Run python @('scripts/verify_ui18_source.py')
Push-Location (Join-Path $Root 'apps/terminal')
try {
  Run npm @('install','--no-audit','--no-fund')
  Run npm @('test')
  Run npm @('run','build')
}
finally { Pop-Location }
if (-not $SkipCoreTests) {
  Run cargo @('test','-p','braintrade-domain','-p','braintrade-runtime')
  Run cargo @('build','-p','braintrade-runtime','--bin','braintrade-core')
  Run python @('-m','unittest','discover','-s','tests','-q')
}
if (-not $SkipPackage) {
  if (-not (Get-Command python -ErrorAction SilentlyContinue)) { throw 'Python needed for SHA256-verified embedded runtime download' }
  Run python @('scripts/prepare-tauri-runtime.py')
}
Push-Location (Join-Path $Root 'apps/tauri')
try { Run cargo @('tauri','build','--bundles','nsis') }
finally { Pop-Location }
Write-Host 'Tauri NSIS installer will be in target/release/bundle/nsis after a successful build.'
Write-Host 'Live MT5 Demo and Telegram must still be validated on your real Windows machine.'
